// slime_mold.cpp
// compile using  `g++ -O3 slime_mold.cpp -o slime_mold`
// video encoding `ffmpeg -framerate 30 -pattern_type glob -i "frame_*.tga" -c:v libsvtav1 -an slime_mold.webm`

#include <vector>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cstdint> // types like uint8_t
#include <iostream>

constexpr int WIDTH = 1280;
constexpr int HEIGHT = 720;
constexpr int NUM_AGENTS = 120000;
constexpr float SENSOR_ANGLE = 0.5f;
constexpr float SENSOR_DIST = 5.0f;
constexpr float TURN_ANGLE = 0.3f;
constexpr float STEP_SIZE = 1.0f;
constexpr float EVAPORATE = 0.85f;
constexpr int FRAMES = 5000;

struct Agent {
    float x, y, angle;
};

std::vector<Agent> agents(NUM_AGENTS);
std::vector<float> field(WIDTH * HEIGHT, 0.0f);

inline int idx(int x, int y) {
    return (y % HEIGHT) * WIDTH + (x % WIDTH);
}

float sampleField(float x, float y) {
    int xi = ((int)std::round(x) + WIDTH) % WIDTH;
    int yi = ((int)std::round(y) + HEIGHT) % HEIGHT;
    return field[idx(xi, yi)];
}

void deposit(Agent &a) {
    int xi = ((int)std::round(a.x) + WIDTH) % WIDTH;
    int yi = ((int)std::round(a.y) + HEIGHT) % HEIGHT;
    field[idx(xi, yi)] += 1.0f;
}

void updateAgents() {
    for (auto &a : agents) {
        // Sample sensors
        float sx = std::cos(a.angle);
        float sy = std::sin(a.angle);

        float c = sampleField(a.x + sx * SENSOR_DIST, a.y + sy * SENSOR_DIST);
        float l = sampleField(a.x + std::cos(a.angle - SENSOR_ANGLE) * SENSOR_DIST,
                              a.y + std::sin(a.angle - SENSOR_ANGLE) * SENSOR_DIST);
        float r = sampleField(a.x + std::cos(a.angle + SENSOR_ANGLE) * SENSOR_DIST,
                              a.y + std::sin(a.angle + SENSOR_ANGLE) * SENSOR_DIST);

        // Adjust angle
        if (c > l && c > r) {
            // Straight
        } else if (l > r) {
            a.angle -= TURN_ANGLE;
        } else if (r > l) {
            a.angle += TURN_ANGLE;
        } else {
            a.angle += (rand() % 2 ? 1 : -1) * TURN_ANGLE;
        }

        // Move
        a.x += std::cos(a.angle) * STEP_SIZE;
        a.y += std::sin(a.angle) * STEP_SIZE;

        // Wrap around
        if (a.x < 0) a.x += WIDTH;
        if (a.x >= WIDTH) a.x -= WIDTH;
        if (a.y < 0) a.y += HEIGHT;
        if (a.y >= HEIGHT) a.y -= HEIGHT;

        deposit(a);
    }
}

void diffuse() {
    // Evaporation only for simplicity
    for (auto &v : field) v *= EVAPORATE;
}

void renderToPixels(std::vector<uint8_t> &pixels) {
    for (int i = 0; i < WIDTH * HEIGHT; i++) {
        uint8_t c = (uint8_t)std::min(field[i] * 10.0f, 255.0f);
        pixels[i * 3 + 0] = c; // Blue
        pixels[i * 3 + 1] = 0; // Green
        pixels[i * 3 + 2] = c; // Red
    }
}

void saveTGA(const char *filename, const std::vector<uint8_t> &pixels) {
    FILE *f = fopen(filename, "wb");
    if (!f) return;

    uint8_t header[18] = {};
    header[2] = 2; // uncompressed true-color
    header[12] = WIDTH & 0xFF;
    header[13] = (WIDTH >> 8) & 0xFF;
    header[14] = HEIGHT & 0xFF;
    header[15] = (HEIGHT >> 8) & 0xFF;
    header[16] = 24; // bits per pixel
    fwrite(header, 1, 18, f);
    fwrite(pixels.data(), 1, pixels.size(), f);
    fclose(f);
}

int main() {
    srand((unsigned)time(0));
    for (auto &a : agents) {
        a.x = rand() % WIDTH;
        a.y = rand() % HEIGHT;
        a.angle = (rand() / (float)RAND_MAX) * 2.0f * M_PI;
    }

    std::vector<uint8_t> pixels(WIDTH * HEIGHT * 3, 0);

    for (int frame = 0; frame < FRAMES; frame++) {
        updateAgents();
        diffuse();
        renderToPixels(pixels);

        // Save every 10 frames
        if (frame % 10 == 0) {
            char filename[64];
            sprintf(filename, "frame_%04d.tga", frame);
	    std::cout << "Saving " << filename << std::endl;
            saveTGA(filename, pixels);
        }
    }

    return 0;
}

